ToonBoomAnimationInc PaletteFile 2
Solid    Black                      0x0d464ca84da6aa7e  60  32  84 255
Solid    Red                        0x0d464ca84da6aa84 173  39  39 255
Solid    White                      0x0d464ca84da6aa81 255 255 255 255
Solid    Green                      0x0d464ca84da6aa87 115 157  56 255
Solid    Blue                       0x0d464ca84da6aa8a  46  50 179 255
Solid    "Vectorized Line"          0x0000000000000003   0   0   0 255
Solid    "New 0"                    0x0d46cd34ae5ce7e3  86 163  14 255
