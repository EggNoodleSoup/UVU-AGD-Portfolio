ToonBoomAnimationInc PaletteFile 2
Solid    Black                      0x0d5afc9a40e014a8   0   0   0 255
Solid    White                      0x0d5afc9a40e014ab 255 255 255 255
Solid    Red                        0x0d5afc9a40e014ae 255   0   0 255
Solid    Green                      0x0d5afc9a40e014b1   0 255   0 255
Solid    Blue                       0x0d5afc9a40e014b4   0   0 255 255
Solid    "Vectorized Line"          0x0000000000000003   0   0   0 255
