ToonBoomAnimationInc PaletteFile 2
Solid    Black                      0x0d46b76403b2762c   0   0   0 255
Solid    White                      0x0d46b76403b2762f 255 255 255 255
Solid    Red                        0x0d46b76403b27632 255   0   0 255
Solid    Green                      0x0d46b76403b27635   0 255   0 255
Solid    Blue                       0x0d46b76403b27638   0   0 255 255
Solid    "Vectorized Line"          0x0000000000000003   0   0   0 255
