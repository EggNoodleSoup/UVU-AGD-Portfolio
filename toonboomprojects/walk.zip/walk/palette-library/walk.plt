ToonBoomAnimationInc PaletteFile 2
Solid    Black                      0x0d51785a9d00166a  42  14  56 255
Solid    Green                      0x0d51785a9d001673   0 255   0 255
Solid    White                      0x0d51785a9d00166d 255 255 255 255
Solid    Red                        0x0d51785a9d001670 205  32  32 255
Solid    Blue                       0x0d51785a9d001676   0   0 255 255
Solid    "Vectorized Line"          0x0000000000000003   0   0   0 255
