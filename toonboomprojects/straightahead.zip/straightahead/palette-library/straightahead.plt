ToonBoomAnimationInc PaletteFile 2
Solid    Black                      0x0d4df8196b30c40e  14  49 112 255
Solid    White                      0x0d4df8196b30c411 255 255 255 255
Solid    Red                        0x0d4df8196b30c414 255   0   0 255
Solid    Green                      0x0d4df8196b30c417   0 255   0 255
Solid    Blue                       0x0d4df8196b30c41a   0   0 255 255
Solid    "Vectorized Line"          0x0000000000000003   0   0   0 255
