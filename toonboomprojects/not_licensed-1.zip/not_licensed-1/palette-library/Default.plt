ToonBoomAnimationInc PaletteFile 2
Solid    "Vectorized Line"          0x0000000000000003   0   0   0 255
Solid    "New 0"                    0x0d53bb9588a062b4 193  42  42 255
Solid    "New 1"                    0x0d53bb9588af308d 133 133 133 255
