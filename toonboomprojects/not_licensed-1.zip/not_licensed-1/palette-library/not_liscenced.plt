ToonBoomAnimationInc PaletteFile 2
Solid    Black                      0x0d53b8a649201447   0   0   0 255
Solid    "Gray 90%"                 0x0d53b8a64920144a  25  25  25 255
Solid    "Gray 80%"                 0x0d53b8a64920144d  51  51  51 255
Solid    "Gray 70%"                 0x0d53b8a649201450  76  76  76 255
Solid    "Gray 60%"                 0x0d53b8a649201453 102 102 102 255
Solid    "Gray 50%"                 0x0d53b8a649201456 127 127 127 255
Solid    "Gray 40%"                 0x0d53b8a649201459 153 153 153 255
Solid    "Gray 30%"                 0x0d53b8a64920145c 179 179 179 255
Solid    "Gray 20%"                 0x0d53b8a64920145f 204 204 204 255
Solid    "Gray 10%"                 0x0d53b8a649201462 230 230 230 255
Solid    White                      0x0d53b8a649201465 255 255 255 255
Solid    "Rough Blue"               0x0d53b8a649201468  55 178 255 255
Solid    "Revision Red"             0x0d53b8a64920146b 255  44   0 255
Solid    Yellow                     0x0d53b8a64920146e 255 255   0 255
